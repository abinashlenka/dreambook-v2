export const categories = [
    {
        id:1,
        value: "Poetry"
    },
    {
        id:2,
        value: "Fiction"
    },
    {
        id:3,
        value: "Non-Fiction"
    },
    {
        id:4,
        value: "Academic"
    },
    {
        id:5,
        value: "Children Books"
    },
    {
        id:6,
        value: "Health & Fitness"
    },
    {
        id:7,
        value: "Business & Finance"
    },
    {
        id:8,
        value: "Other"
    },
];