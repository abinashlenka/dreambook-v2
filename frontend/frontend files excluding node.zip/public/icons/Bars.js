export default function Bars() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
        <path d="M19.5 8H5.5V10H19.5V8ZM19.5 14H5.5V16H19.5V14Z" fill="black"/>
    </svg>
  )
}
