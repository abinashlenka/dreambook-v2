export default function DownArrow() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
        <path d="M12.4987 13.1714L17.4485 8.22168L18.8627 9.63589L12.4987 15.9999L6.13477 9.63589L7.54899 8.22168L12.4987 13.1714Z" fill="#808080"/>
    </svg>
  )
}
