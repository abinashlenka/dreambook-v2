
export default function Edit() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="21" height="20" viewBox="0 0 21 20" fill="none">
        <path d="M6.53553 14.9972H3V11.4617L12.5292 1.93255C12.8547 1.60712 13.3822 1.60712 13.7077 1.93255L16.0647 4.28958C16.3902 4.61501 16.3902 5.14265 16.0647 5.46809L6.53553 14.9972ZM3 16.6639H18V18.3306H3V16.6639Z" fill="#fdd106"/>
    </svg>
  )
}
