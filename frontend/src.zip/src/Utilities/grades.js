export default function Grades() {
    let grades = [
        {
            id:1,
            value:'Grade 1'
        },
        {
            id:2,
            value:'Grade 2'
        },
        {
            id:3,
            value:'Grade 3'
        },
        {
            id:4,
            value:'Grade 4'
        },
        {
            id:5,
            value:'Grade 5'
        },
        {
            id:6,
            value:'Grade 6'
        },
        {
            id:7,
            value:'Grade 7'
        },
        {
            id:8,
            value:'Grade 8'
        },
        {
            id:9,
            value:'Grade 9'
        },
        {
            id:10,
            value:'Grade 10'
        },
        {
            id:11,
            value:'Grade 11'
        },
        {
            id:12,
            value:'Grade 12'
        },
        {
            id:13,
            value:'First Year College'
        },
        {
            id:14,
            value:'Second Year College'
        },
        {
            id:15,
            value:'Third Year College'
        },
        {
            id:16,
            value:'Honours'
        },
        {
            id:17,
            value:'Masters'
        },
        {
            id:18,
            value:'PHD'
        }
    ]
    return grades;
}