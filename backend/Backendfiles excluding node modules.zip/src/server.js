const path = require('path'); // ADDED: Required for path resolution
const dotenv = require('dotenv');
// FIX: Load .env file explicitly from the project root using the absolute path that worked in the diagnostic test
dotenv.config({ path: path.resolve(__dirname, '.env') }); 

const mongoose = require("mongoose");
const cron = require("node-cron");
const cors = require('cors'); 
const logger = require("./config/logger");
const config = require("./config/config");
const amazonService = require("./services/amazon");

const wooCommerceService = require("./services/woocommerce");
const { fetchAndSaveZohoOrders } = require("./services/zohoOrderService");
const app = require("./app"); 
const Order = require("./models/Order");
const routes = require("./routes/v1");
const { computeTopRatedAuthors } = require("./helpers/computeAuthors");
const { sendEmailNotification } = require('./services/notifications');

// ✅ Configure CORS on the imported app
app.use(cors({
  origin: ["http://localhost:3000", "http://localhost:3001"], // Allow your frontend URL
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  credentials: true
}));

let server;

// Connect to MongoDB
mongoose
  .connect(config.mongoose.url, config.mongoose.options)
  .then(() => {
    logger.info("✅ Connected to MongoDB");
  })
  .catch((err) => {
    logger.error("❌ MongoDB Connection Error:", err);
  });

// ---------- Cron Job ----------
cron.schedule("0 * * * *", async () => {
  logger.info("🕒 Running Zoho orders sync...");
  try {
    // await fetchAndSaveAmazonOrders();
    // const amazonOrders = await amazonService.fetchAmazonOrders();
    //  await amazonService.saveAmazonOrders(amazonOrders);
    //  await amazonService.fetchAndSaveAmazonOrdersAndProducts();

    // await wooCommerceService.fetchOrders();
    logger.info("✅ Zoho orders synced successfully");
  } catch (err) {
    logger.error("❌ Error syncing Zoho orders:", err.message);
  }
});

// ---------- Start Server ----------
server = app.listen(config.port, async () => {
  logger.info(`🚀 Server running on port ${config.port}`);
  try {
    // await wooCommerceService.fetchOrders();
    // await amazonService.fetchAndSaveAmazonOrdersAndProducts();

  } catch (err) {
    logger.error("❌ Failed to fetch Zoho orders on start:", err.message);
  }
});

// Graceful exit handlers
const exitHandler = () => {
  if (server) {
    server.close(() => {
      logger.info("Server closed");
      process.exit(1);
    });
  } else {
    process.exit(1);
  }
};

const unexpectedErrorHandler = (error) => {
  logger.error(error);
  exitHandler();
};

process.on("uncaughtException", unexpectedErrorHandler);
process.on("unhandledRejection", unexpectedErrorHandler);
process.on("SIGTERM", () => {
  logger.info("SIGTERM received");
  if (server) {
    server.close();
  }
});