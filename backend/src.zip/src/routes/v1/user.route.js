const express = require('express');

const validate = require('../../middlewares/validate');
// const { firebaseAuth } = require('../../middlewares/firebaseAuth');
const userValidation = require('../../validations/user.validation');

const { userController } = require('../../controllers');
const { fileUploadService } = require('../../microservices');

const router = express.Router();

router.get(
  '/',
  // firebaseAuth('Admin,Employee'),
  userController.getAllUsers
);

router.get(
  '/:id',
  // firebaseAuth('Admin,Employee,Author'),
  userController.getUserById
);

router.get(
  '/get/me',
  // firebaseAuth('All'),
  userController.getMe
);

// for updating userDetails
router.patch(
  '/:id',
  // firebaseAuth('Admin,Employee,Author'),
  userController.updateUser
);

// For role-based users
router.patch('/author/:userId', userController.updateAuthor);
router.patch('/employee/:userId', userController.updateEmployee);
router.patch('/admin/:userId', userController.updateAdmin);

router.patch(
  '/:userId/block-unblock',
  // firebaseAuth('Admin'),
  // validate(userValidation.blockUser),
  userController.blockUnblockUser
);

// New route to update user status
// FIX HERE NEW: Added dedicated route for updating a user's status
router.patch(
  '/:id/status',
  // firebaseAuth('Admin,Employee,Author'),
  userController.updateUserStatus
)

// for deleting a user
router.delete('/delete/me', 
  // validate(userValidation.deleteUser), 
  // firebaseAuth('All'), 
  userController.deleteUser);

// to soft delete a user
router.post('/delete/:userId', 
// validate(userValidation.deleteUser),
//  firebaseAuth('All'), 
userController.softDeleteUser);

module.exports = router;
